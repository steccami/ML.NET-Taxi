﻿using MllML.Model;
using System;
namespace Mll
{
    class Program
    {
        static void Main(string[] args)
        {
            
            

            // Creazione di un modello personalizzato tramite console 
            string vendor = "";
            while (vendor!="VTS" && vendor != "CTM")
            {
                Console.WriteLine("Inserisci il fornitore del servizio (es VTS,CTM...)");
                vendor = Console.ReadLine();
                Console.Clear();
            }
            Console.WriteLine("Inserisci la qualià del servizio fornito (es 1,2,3,4...)");
            float rate = float.Parse(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("Inserisci numero passegeri(es 1,2,3..)");
            float passengers = float.Parse(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("Inserisci durata del viaggio in secondi (es 100,500,1000..)");
            float time = float.Parse(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("Inserisci distanza percorsa km (es 1.2,2.6,4.5...)");
            float distance = float.Parse(Console.ReadLine());
            Console.Clear();
            string payment = "";
            while (payment != "CRD" && payment != "CSH")
            {
                Console.WriteLine("Inserisci il tipo di pagamento (es CRD carta di cradito, CSH contanti)");
                payment = Console.ReadLine();
                Console.Clear();
            }
            Console.Clear();

            // Fa una predizione del prezzo utilizzando il modello gia precompilato
            ModelOutput result = ConsumeModel.Predict(new ModelInput() {Vendor_id=vendor,Rate_code=rate,Passenger_count=passengers,Trip_time_in_secs=time,Trip_distance=distance,Payment_type=payment });
            Console.WriteLine("Prezzo: " + result.Score+"$");
        
            Console.ReadLine();
        }
    }

}
