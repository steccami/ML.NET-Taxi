

using System;
using System.IO;
using System.Linq;
using Microsoft.ML;
using MllML.Model;

namespace MllML.ConsoleApp
{
    class Program
    {
        //Seleziono la cartella del dataset
        private const string DATA_FILEPATH = @"C:\Users\nikxt\Desktop\Mll\taxi-fare-test.csv";

        static void Main(string[] args)
        {
            // Crea un semplice esempio di istanza dal dataset
            ModelInput sampleData = CreateSingleDataSample(DATA_FILEPATH);

            // Fa un semplice esempio di predizione
            var predictionResult = ConsumeModel.Predict(sampleData);

            Console.WriteLine($"vendor_id: {sampleData.Vendor_id}");
            Console.WriteLine($"rate_code: {sampleData.Rate_code}");
            Console.WriteLine($"passenger_count: {sampleData.Passenger_count}");
            Console.WriteLine($"trip_time_in_secs: {sampleData.Trip_time_in_secs}");
            Console.WriteLine($"trip_distance: {sampleData.Trip_distance}");
            Console.WriteLine($"payment_type: {sampleData.Payment_type}");
            Console.WriteLine($"\n\n Fare_amount: {sampleData.Fare_amount} \nPredicted Fare_amount: {predictionResult.Score}\n\n");
          
            Console.ReadKey();
        }

       
        #region CreateSingleDataSample
        // Carica una riga del dataset 
        private static ModelInput CreateSingleDataSample(string dataFilePath)
        {
            // Create MLContext
            MLContext mlContext = new MLContext();

            // Load dataset
            IDataView dataView = mlContext.Data.LoadFromTextFile<ModelInput>(
                                            path: dataFilePath,
                                            hasHeader: true,
                                            separatorChar: ',',
                                            allowQuoting: true,
                                            allowSparse: false);

            // Use first line of dataset as model input
            // You can replace this with new test data (hardcoded or from end-user application)
            ModelInput sampleForPrediction = mlContext.Data.CreateEnumerable<ModelInput>(dataView, false)
                                                                        .First();
            return sampleForPrediction;
        }
        #endregion
    }
}
