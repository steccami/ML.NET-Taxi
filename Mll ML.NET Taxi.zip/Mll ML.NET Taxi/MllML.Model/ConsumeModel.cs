

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.ML;
using MllML.Model;

namespace MllML.Model
{
    public class ConsumeModel
    {
     
        public static ModelOutput Predict(ModelInput input)
        {

            MLContext mlContext = new MLContext();

            // Carica il modello pre addestrato
            string modelPath = @"C:\Users\nikxt\AppData\Local\Temp\MLVSTools\MllML\MllML.Model\MLModel.zip";
            ITransformer mlModel = mlContext.Model.Load(modelPath, out var modelInputSchema);
            var predEngine = mlContext.Model.CreatePredictionEngine<ModelInput, ModelOutput>(mlModel);

            // Utilizza il modello per fare predizioni
            ModelOutput result = predEngine.Predict(input);
            return result;
        }
    }
}
