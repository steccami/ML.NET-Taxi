

using System;
using Microsoft.ML.Data;

namespace MllML.Model
{
    public class ModelOutput
    {
        //Diamo le informazioni di output
        public float Score { get; set; }
    }
}
